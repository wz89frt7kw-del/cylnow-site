# Deploying CYLNOW to Cloudflare (free tier)

## 1. One-time setup

```
npm install -g wrangler
wrangler login
```

## 2. Create the database

```
wrangler d1 create cylnow-db
```

This prints a `database_id`. Copy it into `wrangler.toml`, replacing
`REPLACE_WITH_YOUR_D1_DATABASE_ID`.

## 3. Load the schema + seed data

```
wrangler d1 execute cylnow-db --remote --file=./schema.sql
```

The seed data is **national/statewide hotlines only** (211, the
National DV Hotline, VA homeless veterans line). No specific local
shelters are pre-loaded — see "Adding real local resources" below.
This is deliberate: CYLNOW's whole premise is that nothing goes live
until it's been checked, so I didn't want to plant placeholder local
listings that look verified but aren't.

## 4. Deploy

```
wrangler pages deploy . --project-name=cylnow
```

Or connect the folder to a GitHub repo and link it in the Cloudflare
Pages dashboard for auto-deploys on push.

## 5. Bind the database to the Pages project

In the Cloudflare dashboard: **Pages → your project → Settings →
Functions → D1 database bindings** → add binding named `DB` pointing
at `cylnow-db`. (If you deployed with `wrangler pages deploy`, the
binding in `wrangler.toml` should pick this up automatically —
confirm it shows up in the dashboard.)

Redeploy after adding the binding if it wasn't picked up automatically.

## 6. Adding real local resources

Every row needs to be checked against a live source before it goes in
— that's the product's core promise. For each one:

```sql
INSERT INTO resources (name, category, county, phone, address, eligibility, notes, call_before_traveling, status, last_verified)
VALUES ('Org name', 'shelter', 'Los Angeles', '555-555-5555', '123 Main St', 'Who qualifies', 'Notes', 0, 'active', '2026-08-27');
```

Run it with:

```
wrangler d1 execute cylnow-db --remote --command="INSERT INTO resources (...) VALUES (...);"
```

`category` must be one of: `shelter`, `food`, `dv`, `legal`,
`employment`, `veterans`.
`county` must be one of: `Los Angeles`, `Orange`, `San Bernardino`,
`San Diego`.
Set `call_before_traveling` to `1` if availability wasn't confirmed
live (e.g. no guaranteed bed) — the card will show the "call first"
warning.
Set `status` to `inactive` instead of deleting a row you want to keep
for records but stop showing.

---

# Security review — what's in place, and what to still check

## Already handled in this build

- **SQL injection**: every query in `functions/api/*.js` uses
  parameterized `.bind()` calls — no string concatenation into SQL
  anywhere.
- **XSS**: every dynamic value inserted via `innerHTML` on the
  frontend goes through `escapeHtml()` first. (I found and fixed one
  gap — `last_verified` wasn't escaped in the version you had; it is
  now.)
- **Input validation on `/api/feedback`**: `resource_id` must be a
  positive integer that actually exists in the table; `feedback_type`
  must be one of exactly three allowed values. Anything else is
  rejected with a 400 before it reaches the database.
- **IP privacy**: raw IP addresses are never stored. `/api/feedback`
  hashes the requester's IP (SHA-256) before writing it, so the row
  can't be reversed to an address. This matters specifically because
  this tool serves domestic-violence survivors — don't relax this.
- **Basic anti-spam**: a 60-second cooldown per (hashed IP, resource,
  feedback type) stops trivial repeat-click abuse of the feedback
  counts without requiring accounts or CAPTCHAs.
- **Method restrictions**: `/api/resources` only accepts GET;
  `/api/feedback` only accepts POST. Other methods get a clean 405
  instead of falling through to a default error.
- **No stack traces leaked**: errors are logged server-side
  (`console.error`, visible in `wrangler pages deployment tail`) but
  the response body only ever contains a generic message.
- **CSP** (already in your `<head>`): restricts scripts, styles, and
  connections to same-origin, blocks framing entirely
  (`frame-ancestors 'none'`), and sets `X-Content-Type-Options:
  nosniff`. The API responses set the nosniff header too.
- **Quick Exit** and the safety strip (911, DV hotline) render before
  any JavaScript runs, so they're visible even if the resource fetch
  fails.

## Recommended, not yet configured (do these in the Cloudflare dashboard — no extra cost on free tier)

- **Force HTTPS**: Pages does this by default, but confirm under
  SSL/TLS → Edge Certificates → "Always Use HTTPS" is on.
- **Rate limiting rule**: Free tier includes a small number of basic
  WAF rate-limiting rules. Add one on `/api/feedback` (e.g. 20
  requests/minute per IP) as a second layer on top of the app-level
  cooldown — this protects against distributed abuse the app-level
  check alone won't catch.
- **HSTS**: SSL/TLS → Edge Certificates → enable HSTS once you've
  confirmed HTTPS works everywhere; this prevents any accidental
  plain-HTTP loads later.
- **D1 backups**: export the database periodically
  (`wrangler d1 export cylnow-db --remote --output=backup.sql`),
  especially before bulk-editing resources.
- **Don't expose an admin UI on this same Pages project** without
  authentication — right now there is no write access to `resources`
  from the public site (only `feedback` accepts writes, and it's
  tightly scoped). If you build an editor for adding/verifying
  resources later, put it behind Cloudflare Access or similar rather
  than as an open route.

## Explicitly out of scope for this pass

- User accounts / login — none exist, none are needed for the current
  feature set.
- Analytics/tracking — none added. If you add any later, keep it off
  by default given the sensitivity of who uses this site, and update
  the CSP `connect-src` accordingly (it currently blocks anything
  that isn't same-origin).
