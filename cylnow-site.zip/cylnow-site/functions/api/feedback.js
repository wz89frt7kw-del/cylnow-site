// POST /api/feedback
//
// Security notes:
// - All values are validated against a strict allowlist/type before
//   ever touching a query, and every query uses bound parameters
//   (no string concatenation), so SQL injection isn't possible here.
// - Requesting IPs are hashed (SHA-256) before storage. This is a
//   domestic-violence-adjacent tool, so we never persist a raw IP
//   address that could later identify or geolocate someone.
// - A same-origin check on the Origin header blocks naive
//   cross-site scripted submissions (defense in depth; the page's
//   CSP `connect-src 'self'` already stops this from the browser
//   side for normal use).
// - A short per-IP-hash/resource/type cooldown blocks trivial
//   spam/abuse of the feedback counters without needing a login.

const ALLOWED_FEEDBACK_TYPES = ["worked", "no_answer", "hours_wrong"];
const COOLDOWN_SECONDS = 60;

export async function onRequestPost(context) {
  const { request, env } = context;

  // Same-origin check (defense in depth)
  const origin = request.headers.get("Origin");
  if (origin) {
    try {
      const originHost = new URL(origin).host;
      const requestHost = new URL(request.url).host;
      if (originHost !== requestHost) {
        return jsonResponse({ error: "Forbidden" }, 403);
      }
    } catch {
      return jsonResponse({ error: "Forbidden" }, 403);
    }
  }

  // Parse + validate body
  let body;
  try {
    body = await request.json();
  } catch {
    return jsonResponse({ error: "Invalid request body." }, 400);
  }

  const resourceId = Number(body?.resource_id);
  const feedbackType = typeof body?.feedback_type === "string" ? body.feedback_type : "";

  if (!Number.isInteger(resourceId) || resourceId <= 0) {
    return jsonResponse({ error: "Invalid resource." }, 400);
  }
  if (!ALLOWED_FEEDBACK_TYPES.includes(feedbackType)) {
    return jsonResponse({ error: "Invalid feedback type." }, 400);
  }

  try {
    // Confirm the resource actually exists before recording feedback on it
    const resource = await env.DB.prepare("SELECT id FROM resources WHERE id = ?")
      .bind(resourceId)
      .first();
    if (!resource) {
      return jsonResponse({ error: "Resource not found." }, 404);
    }

    const ip = request.headers.get("CF-Connecting-IP") || "unknown";
    const ipHash = await sha256Hex(ip);

    // Basic anti-spam cooldown per (ip hash, resource, feedback type)
    const recent = await env.DB.prepare(
      `SELECT id FROM feedback
       WHERE resource_id = ? AND feedback_type = ? AND ip_hash = ?
         AND created_at > datetime('now', ?)
       LIMIT 1`
    )
      .bind(resourceId, feedbackType, ipHash, `-${COOLDOWN_SECONDS} seconds`)
      .first();

    if (recent) {
      return jsonResponse({ error: "Please wait a moment before submitting again." }, 429);
    }

    await env.DB.prepare(
      "INSERT INTO feedback (resource_id, feedback_type, ip_hash) VALUES (?, ?, ?)"
    )
      .bind(resourceId, feedbackType, ipHash)
      .run();

    return jsonResponse({ success: true }, 200);
  } catch (err) {
    console.error("POST /api/feedback failed:", err);
    return jsonResponse({ error: "Couldn't submit feedback right now." }, 500);
  }
}

export async function onRequestGet() {
  return jsonResponse({ error: "Method not allowed" }, 405, { Allow: "POST" });
}

function jsonResponse(obj, status, extraHeaders = {}) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: {
      "Content-Type": "application/json",
      "Cache-Control": "no-store",
      "X-Content-Type-Options": "nosniff",
      ...extraHeaders,
    },
  });
}

async function sha256Hex(str) {
  const data = new TextEncoder().encode(str);
  const digest = await crypto.subtle.digest("SHA-256", data);
  return Array.from(new Uint8Array(digest))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}
