// GET /api/resources
// Read-only endpoint. Takes no user input, so there's no injection
// surface here — but we still use a prepared statement for consistency
// and because it costs nothing.

export async function onRequestGet(context) {
  try {
    const { results } = await context.env.DB.prepare(
      `SELECT id, name, category, county, phone, address, eligibility,
              notes, call_before_traveling, status, last_verified
       FROM resources
       ORDER BY name`
    ).all();

    const resources = results.map((r) => ({
      ...r,
      call_before_traveling: !!r.call_before_traveling,
    }));

    return new Response(JSON.stringify(resources), {
      status: 200,
      headers: {
        "Content-Type": "application/json",
        "Cache-Control": "no-store",
        "X-Content-Type-Options": "nosniff",
      },
    });
  } catch (err) {
    console.error("GET /api/resources failed:", err);
    return new Response(JSON.stringify({ error: "Unable to load resources right now." }), {
      status: 500,
      headers: { "Content-Type": "application/json", "Cache-Control": "no-store" },
    });
  }
}

// Reject any other method on this route instead of falling through
// to a default 404/500 that could leak stack info.
export async function onRequestPost() {
  return methodNotAllowed();
}
export async function onRequestPut() {
  return methodNotAllowed();
}
export async function onRequestDelete() {
  return methodNotAllowed();
}

function methodNotAllowed() {
  return new Response(JSON.stringify({ error: "Method not allowed" }), {
    status: 405,
    headers: { "Content-Type": "application/json", Allow: "GET" },
  });
}
