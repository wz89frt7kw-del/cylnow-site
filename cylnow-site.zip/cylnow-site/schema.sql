-- CYLNOW database schema (Cloudflare D1 / SQLite)

DROP TABLE IF EXISTS feedback;
DROP TABLE IF EXISTS resources;

CREATE TABLE resources (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  category TEXT NOT NULL CHECK (category IN ('shelter','food','dv','legal','employment','veterans')),
  county TEXT NOT NULL CHECK (county IN ('Los Angeles','Orange','San Bernardino','San Diego')),
  phone TEXT,
  address TEXT,
  eligibility TEXT,
  notes TEXT,
  call_before_traveling INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','inactive')),
  last_verified TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_resources_category ON resources(category);
CREATE INDEX idx_resources_county ON resources(county);
CREATE INDEX idx_resources_status ON resources(status);

CREATE TABLE feedback (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  resource_id INTEGER NOT NULL REFERENCES resources(id),
  feedback_type TEXT NOT NULL CHECK (feedback_type IN ('worked','no_answer','hours_wrong')),
  ip_hash TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_feedback_resource ON feedback(resource_id);
CREATE INDEX idx_feedback_created ON feedback(created_at);

-- ─────────────────────────────────────────────────────────────
-- Seed data: NATIONAL / STATEWIDE hotlines only.
--
-- These are real, stable, publicly-documented numbers that don't
-- require county-level field verification. They're safe defaults
-- so the site isn't empty at launch.
--
-- IMPORTANT: No specific local shelters, food banks, or county
-- programs are seeded here. CYLNOW's entire premise is that every
-- listing is checked against a live source before publishing —
-- fabricating placeholder local listings would violate that and
-- could send someone in crisis to a nonexistent or wrong resource.
-- Add real local resources yourself after verifying each one
-- (call the number, confirm hours/eligibility, then insert).
-- ─────────────────────────────────────────────────────────────

INSERT INTO resources (name, category, county, phone, address, eligibility, notes, call_before_traveling, status, last_verified) VALUES
('211 — Community Resource Line', 'shelter', 'Los Angeles', '211', NULL, 'Open to anyone', 'Free 24/7 line that can locate current local shelter, food, and social service openings by area.', 0, 'active', '2026-08-27'),
('211 — Community Resource Line', 'shelter', 'Orange', '211', NULL, 'Open to anyone', 'Free 24/7 line that can locate current local shelter, food, and social service openings by area.', 0, 'active', '2026-08-27'),
('211 — Community Resource Line', 'shelter', 'San Bernardino', '211', NULL, 'Open to anyone', 'Free 24/7 line that can locate current local shelter, food, and social service openings by area.', 0, 'active', '2026-08-27'),
('211 — Community Resource Line', 'shelter', 'San Diego', '211', NULL, 'Open to anyone', 'Free 24/7 line that can locate current local shelter, food, and social service openings by area.', 0, 'active', '2026-08-27'),
('National Domestic Violence Hotline', 'dv', 'Los Angeles', '1-800-799-7233', NULL, 'Anyone experiencing domestic violence', 'Free, confidential, 24/7. Also available by text (START to 88788) and chat at thehotline.org.', 0, 'active', '2026-08-27'),
('National Domestic Violence Hotline', 'dv', 'Orange', '1-800-799-7233', NULL, 'Anyone experiencing domestic violence', 'Free, confidential, 24/7. Also available by text (START to 88788) and chat at thehotline.org.', 0, 'active', '2026-08-27'),
('National Domestic Violence Hotline', 'dv', 'San Bernardino', '1-800-799-7233', NULL, 'Anyone experiencing domestic violence', 'Free, confidential, 24/7. Also available by text (START to 88788) and chat at thehotline.org.', 0, 'active', '2026-08-27'),
('National Domestic Violence Hotline', 'dv', 'San Diego', '1-800-799-7233', NULL, 'Anyone experiencing domestic violence', 'Free, confidential, 24/7. Also available by text (START to 88788) and chat at thehotline.org.', 0, 'active', '2026-08-27'),
('VA National Call Center for Homeless Veterans', 'veterans', 'Los Angeles', '1-877-424-3838', NULL, 'Veterans and their families', 'Free, confidential, 24/7. Connects veterans to local VA homelessness programs and benefits.', 0, 'active', '2026-08-27'),
('VA National Call Center for Homeless Veterans', 'veterans', 'Orange', '1-877-424-3838', NULL, 'Veterans and their families', 'Free, confidential, 24/7. Connects veterans to local VA homelessness programs and benefits.', 0, 'active', '2026-08-27'),
('VA National Call Center for Homeless Veterans', 'veterans', 'San Bernardino', '1-877-424-3838', NULL, 'Veterans and their families', 'Free, confidential, 24/7. Connects veterans to local VA homelessness programs and benefits.', 0, 'active', '2026-08-27'),
('VA National Call Center for Homeless Veterans', 'veterans', 'San Diego', '1-877-424-3838', NULL, 'Veterans and their families', 'Free, confidential, 24/7. Connects veterans to local VA homelessness programs and benefits.', 0, 'active', '2026-08-27'),
('211 — CalFresh & Food Resource Line', 'food', 'Los Angeles', '211', NULL, 'Open to anyone', 'Can locate same-day meal programs and food banks currently operating in your area.', 0, 'active', '2026-08-27'),
('211 — CalFresh & Food Resource Line', 'food', 'Orange', '211', NULL, 'Open to anyone', 'Can locate same-day meal programs and food banks currently operating in your area.', 0, 'active', '2026-08-27'),
('211 — CalFresh & Food Resource Line', 'food', 'San Bernardino', '211', NULL, 'Open to anyone', 'Can locate same-day meal programs and food banks currently operating in your area.', 0, 'active', '2026-08-27'),
('211 — CalFresh & Food Resource Line', 'food', 'San Diego', '211', NULL, 'Open to anyone', 'Can locate same-day meal programs and food banks currently operating in your area.', 0, 'active', '2026-08-27');
